<?php
//Website Settings
$site_title = "Nayrah Ads";
$about_site = "A free classified ads website for Cars, Phones, Electronics, Smartphones, Real estate, and everything else. Find what you're looking for or create your own ad for free!.";

date_default_timezone_set('Africa/Dar_es_salaam');

$currency = "Tsh/=";
$installation_path = "localhost/nayrah_ads";


//Social Network Setings
$facebook_link = "#";
$twitter_link = "#";
$instagram_link = "#";
$googleplus_link = "#";

//Database Settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ads_db";

//Contact Settings
$site_email = "azizidaudy@gmail.com";
$site_phone = "+255 684 307 028";
$site_address = "P.O Box 14859 Dar es salaam, Tanzania";

//SMTP Settings
$smtp_host = '';
$smtp_user = '';
$smtp_pass = '';




?>